import tkinter as tk
from tkinter import messagebox, PhotoImage

# ---------------------- Global Variables ----------------------
# Stores financial data
total_income = 0.0      # Total income tracked
total_expenses = 0.0    # Total expenses tracked
savings_goal = 0.0      # Goal amount for savings

# ---------------------- Validation Function ----------------------
def validate_float(value):
    """
    Ensures the user input is a valid positive float.
    Returns the float value if valid, otherwise returns None.
    """
    try:
        val = float(value)
        if val < 0:  # Prevents negative values
            raise ValueError
        return val
    except ValueError:
        return None

# ---------------------- Update Labels ----------------------
def update_labels():
    """Updates the displayed financial summary (income, expenses, savings goal)."""
    lbl_income.config(text=f"Total Income: ${total_income:.2f}")
    lbl_expense.config(text=f"Total Expenses: ${total_expenses:.2f}")
    lbl_savings.config(text=f"Savings Goal: ${savings_goal:.2f}")

# ---------------------- Functions for Income & Expenses ----------------------
def add_income():
    """Adds user-inputted income to total_income and updates the UI."""
    global total_income
    amount = validate_float(entry_income.get())

    if amount is not None:
        total_income += amount  # Add to total income
        entry_income.delete(0, tk.END)  # Clear input field
        update_labels()  # Refresh UI labels
    else:
        messagebox.showerror("Invalid Input", "Please enter a valid positive number.")

def add_expense():
    """Adds user-inputted expense to total_expenses and updates the UI."""
    global total_expenses
    amount = validate_float(entry_expense.get())

    if amount is not None:
        total_expenses += amount  # Add to total expenses
        entry_expense.delete(0, tk.END)  # Clear input field
        update_labels()  # Refresh UI labels
    else:
        messagebox.showerror("Invalid Input", "Please enter a valid positive number.")

# ---------------------- Savings Window ----------------------
def open_savings_window():
    """Opens a new window allowing the user to set a savings goal."""
    savings_window = tk.Toplevel(root)
    savings_window.title("Savings Goal")
    savings_window.geometry("300x250")

    # Savings Image
    try:
        savings_img = PhotoImage(file="savings_icon.png")  # Load savings image
        savings_img = savings_img.subsample(4, 4)  # Resize image
        lbl_savings_img = tk.Label(savings_window, image=piggy_bank)
        lbl_savings_img.image = piggy_bank  # Keep reference
        lbl_savings_img.pack(pady=5)
    except Exception:
        print("Savings image not found. Place 'savings_icon.png' in the folder.")

    # Input Fields
    lbl_goal = tk.Label(savings_window, text="Savings Goal ($):")
    lbl_goal.pack(pady=5)
    entry_goal = tk.Entry(savings_window)
    entry_goal.pack(pady=5)

    lbl_months = tk.Label(savings_window, text="Months to Save:")
    lbl_months.pack(pady=5)
    entry_months = tk.Entry(savings_window)
    entry_months.pack(pady=5)

    def set_savings_goal():
        """Calculates and updates the savings goal based on user input."""
        global savings_goal
        goal = validate_float(entry_goal.get())
        months = validate_float(entry_months.get())

        if goal is not None and months is not None and months > 0:
            savings_goal = goal
            monthly_savings = goal / months
            update_labels()
            messagebox.showinfo("Savings Plan", f"Save ${monthly_savings:.2f} per month.")
        else:
            messagebox.showerror("Invalid Input", "Enter valid positive numbers.")

    btn_save = tk.Button(savings_window, text="Set Goal", command=set_savings_goal)
    btn_save.pack(pady=10)

# ---------------------- Main Window ----------------------
root = tk.Tk()
root.title("Personal Finance Tracker")
root.geometry("400x550")

# ---------------------- Image Display ----------------------
try:
    # Load and display the finance tracker image
    img = PhotoImage(file="finance_icon.png")
    img = img.subsample(4, 4)  # Resize image (reduce by 4x)
    img_label = tk.Label(root, image=img, text="Finance Tracker", compound="top")
    img_label.image = img  # Keep reference
    img_label.pack(pady=5)
except Exception:
    print("Image not found. Place 'finance_icon.png' in the same folder.")

# ---------------------- Labels ----------------------
lbl_income = tk.Label(root, text="Total Income: $0.00", font=("Arial", 12))
lbl_expense = tk.Label(root, text="Total Expenses: $0.00", font=("Arial", 12))
lbl_savings = tk.Label(root, text="Savings Goal: $0.00", font=("Arial", 12))

lbl_income.pack(pady=5)
lbl_expense.pack(pady=5)
lbl_savings.pack(pady=5)

# ---------------------- Input & Buttons for Income ----------------------
entry_income = tk.Entry(root, width=20)  # Input field for income
entry_income.pack(pady=5)
btn_add_income = tk.Button(root, text="Add Income", command=add_income)  # Button to add income
btn_add_income.pack(pady=5)

# ---------------------- Input & Buttons for Expenses ----------------------
entry_expense = tk.Entry(root, width=20)  # Input field for expenses
entry_expense.pack(pady=5)
btn_add_expense = tk.Button(root, text="Add Expense", command=add_expense)  # Button to add expense
btn_add_expense.pack(pady=5)

# ---------------------- Savings Goal Button ----------------------
btn_savings = tk.Button(root, text="Set Savings Goal", command=open_savings_window)
btn_savings.pack(pady=5)

# ---------------------- Exit Button ----------------------
btn_exit = tk.Button(root, text="Exit", command=root.quit)
btn_exit.pack(pady=5)

# Run the application
root.mainloop()

